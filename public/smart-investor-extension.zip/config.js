// Generated deployments replace the publishable-key placeholder through scripts/build-extension.mjs.
export const SUPABASE_URL = "https://lfaziomdrpvodfctnwdm.supabase.co";
export const SUPABASE_PUBLISHABLE_KEY = "sb_publishable_A35DfaJQy8jbI4sl8e0euA_5UOww2dN";
export const DASHBOARD_URL = "https://smart-investor-co-pilot.lovable.app";
